import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from utils.data_loader import load_data

st.set_page_config(page_title="Product Analysis", layout="wide")
st.title("Product Analysis")

# Load data
df = load_data()

# Sales by Product Line 
st.subheader("Total Sales by Product Category")
product_sales = df.groupby("product_line")["total"].sum().sort_values().reset_index()

fig1, ax1 = plt.subplots()
sns.barplot(data=product_sales, x="total", y="product_line", palette="viridis", ax=ax1)
ax1.set_xlabel("Total Sales (₹)")
ax1.set_ylabel("Product Line")
ax1.set_title("Total Revenue by Product Line")
st.pyplot(fig1)

st.markdown("""
            Beauty and health products seem to slighlty underperform compared to other categories.This could be due to the very nature of such products which are often considered non-essential or luxury items.
            The store could consider introducing more promotions or discounts in these categories to boost sales.
            """)

# Average Revenue per Product 
st.subheader("Average Sales per Product Line")
avg_sales = df.groupby("product_line")["total"].mean().reset_index()

fig3, ax3 = plt.subplots()
sns.barplot(data=avg_sales, x="product_line", y="total", palette="coolwarm", ax=ax3)
ax3.set_xticklabels(ax3.get_xticklabels(), rotation=30)
ax3.set_ylabel("Average Sale Value (₹)")
ax3.set_title("Average Revenue per Product Line")
st.pyplot(fig3)

# Product Line Ratings 
st.subheader("Customer Ratings per Product Line")
fig4, ax4 = plt.subplots()
sns.boxplot(data=df, x="product_line", y="rating", palette="Pastel1", ax=ax4)
ax4.set_xticklabels(ax4.get_xticklabels(), rotation=30)
ax4.set_title("Ratings by Product Line")
st.pyplot(fig4)

