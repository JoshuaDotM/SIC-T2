import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from utils.data_loader import load_data

st.set_page_config(page_title="DMart Sales Trends", layout="wide")
st.title("Sales Trends Over Time")

# Load data as we did in the previous pages
df = load_data()

# Add new date-based columns
df["month"] = df["date"].dt.month
df["year"] = df["date"].dt.year
df["month_name"] = df["date"].dt.strftime("%b")

# Defining the seasons based on the indian seasonal cycle
def get_season(month):
    if month in [3, 4, 5]:
        return "Summer"
    elif month in [6, 7, 8, 9]:
        return "Monsoon"
    else:
        return "Winter"

df["season"] = df["month"].apply(get_season)

# Total Sales Over Time
st.subheader("Daily Sales Over Time")
daily_sales = df.groupby("date")["total"].sum().reset_index()
fig1, ax1 = plt.subplots(figsize=(10, 4))
sns.lineplot(data=daily_sales, x="date", y="total", ax=ax1)
ax1.set_ylabel("Sales (₹)")
ax1.set_title("Total Sales by Day")
st.pyplot(fig1)

st.markdown("""
**Insight:**  
This is a line graph showing the total sales over different days, which helps identify trends and seasonal patterns in sales.

**Inference:**
  Peaks may indicate special promotions or seasonal demand. We could notice a strong depression/decline in the trajectory of the line graph particularly in the month's end. This could be correlated with the end of the month when customers might have less disposable income after paying bills, leading to lower sales.
            """)

# Monthly Sales
st.subheader("Monthly Sales Trend")
monthly_sales = df.groupby(["year", "month_name"])["total"].sum().reset_index()
monthly_sales["month_number"] = pd.to_datetime(monthly_sales["month_name"], format="%b").dt.month
monthly_sales = monthly_sales.sort_values(by=["year", "month_number"])

fig2, ax2 = plt.subplots(figsize=(10, 4))
sns.lineplot(data=monthly_sales, x="month_name", y="total", hue="year", marker="o", ax=ax2)
ax2.set_ylabel("Sales (₹)")
ax2.set_title("Monthly Sales by Year")
st.pyplot(fig2)

st.markdown("""**Observation**: There is a massive dip right in the month of February. 
                **Inference:** February often follows the peak sales season of the holiday period (November-December) and the subsequent January sales. Consumers tend to spend less in February as they recover from holiday expenses. """)

# Seasonal Sales
st.subheader("Seasonal Sales Distribution")
seasonal_sales = df.groupby("season")["total"].sum().reset_index()

fig3, ax3 = plt.subplots()
sns.barplot(data=seasonal_sales, x="season", y="total", ax=ax3, palette="pastel")
ax3.set_ylabel("Sales (₹)")
ax3.set_title("Total Sales by Season")
st.pyplot(fig3)

st.markdown("""
**Insight:**  
This bar-graph classifies the sales of all the months for a given year into seasons. the logic used here to classify them is based on the season cycles particularly in India.

**Inference:**
  we can observe a significant increase in sales during the winter season, which may be attributed to festivals and holidays like Dussera and Diwali. The summer season shows a dip in sales, possibly due to lower consumer spending during the hotter months.
  This seasonal dependency particularly in online platforms is very well explained in the Forign Trade Journal 2024, Vol. 6, Issue 2, Part C - A study on the impact of seasonal sales on online shopping trends in India: A study of amazon and Flipkart. I used the data to further solidify the inference that the sales are highly dependent on the seasons and the festivals that come along with them. link : https://doi.org/10.33545/26633140.2024.v6.i2c.133
            """)

