import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from utils.data_loader import load_data

st.set_page_config(page_title="Payment Insights", layout="wide")
st.title("Payment Insights")

# Load data
df = load_data()

#  Payment Method Distribution 
st.subheader("Payment Method Distribution")
payment_counts = df["payment"].value_counts()

fig1, ax1 = plt.subplots()
colors = sns.color_palette("pastel")[0:5]
ax1.pie(payment_counts, labels=payment_counts.index, autopct='%1.1f%%', colors=colors, startangle=90)
ax1.axis("equal")
st.pyplot(fig1)

# Total Sales by Payment Type
st.subheader("Revenue by Payment Type")
payment_sales = df.groupby("payment")["total"].sum().reset_index()

fig2, ax2 = plt.subplots()
sns.barplot(data=payment_sales, x="payment", y="total", palette="Blues_d", ax=ax2)
ax2.set_title("Total Revenue by Payment Type")
ax2.set_ylabel("Total Sales (₹)")
st.pyplot(fig2)

st.markdown("""
**Observation:** The bar chart shows that cash payments dominate the sales, followed by credit card and digital wallets. This indicates a strong preference for cash transactions among customers.
            
**Inference:** The store could consider offering incentives for digital payments to encourage their use, such as discounts. This could help reduce cash handling costs and improve transaction efficiency.
It could also partner with digital wallet providers such as gpay phonepay etc. to offer exclusive deals or cashback offers to customers who use these payment methods. This could help increase the adoption of digital payments and reduce the reliance on cash transactions hence promoting the vision of digital India.
           """ )

# Customer Rating by Payment Type 
st.subheader("Customer Ratings by Payment Method")
fig3, ax3 = plt.subplots()
sns.boxplot(data=df, x="payment", y="rating", palette="Set3", ax=ax3)
ax3.set_title("Customer Ratings across Payment Methods")
st.pyplot(fig3)

st.markdown("""
The customers are quite satisfied with the payment methods, as indicated by the median line (at around 7) in the box plot. But credit card tends to have a slightly higher rating overall indicate by the upper quartile value.
""")
