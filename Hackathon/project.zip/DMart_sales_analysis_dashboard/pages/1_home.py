import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from utils.data_loader import load_data

st.set_page_config(page_title="DMart Dashboard - Home", layout="wide")
st.title("DMart Sales Overview")

# Load cleaned data
df = load_data()

# KPIs
total_sales = df["total"].sum()
total_transactions = len(df)
avg_rating = round(df["rating"].mean(), 2)
total_quantity = df["quantity"].sum()

st.markdown("Key Performance Indicators")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Sales", f"₹{total_sales:,.0f}")
col2.metric("Transactions", total_transactions)
col3.metric("Avg. Rating", avg_rating)
col4.metric("Products Sold", total_quantity)

st.image("dmart@logotyp.us.png", caption="Created by Joshua Maries", use_container_width=True)


