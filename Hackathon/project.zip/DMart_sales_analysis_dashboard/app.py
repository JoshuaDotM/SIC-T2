import streamlit as st

st.set_page_config(
    page_title="DMart Sales Dashboard",
    page_icon="**",
    layout="wide"
)

st.title("Welcome to the DMart Sales Analytics Dashboard")

st.markdown("""
Welcome to the **DMart Sales Analysis** dashboard!
This dashboard is designed to provide in-depth insights into customer behavior, product trends, payment preferences, and more.
 DMart is one of India’s most successful and efficient retail supply chains,
 known for its streamlined operations, cost-effective sourcing,
and deep understanding of consumer behavior.Studying DMart’s
supply chain model is important because it demonstrates 
how operational excellence and data-driven decisions can lead to consistent profitability
and customer loyalty. Analyzing their data helps uncover key insights into sales trends, 
customer preferences,
and inventory management strategies that can be applied across the retail industry.
Use the navigation sidebar to explore: 
- Sales Trends
- Customer Behavior
- Product Analysis
- Payment Insights
""")
